
/**
 * Página principal da aplicação
 * Renderiza o componente de gerenciamento de prioridades
 */

import PedidosPrioridade from "../components/PedidosPrioridade";


const Index = () => {
  return <PedidosPrioridade />;
};

export default Index;