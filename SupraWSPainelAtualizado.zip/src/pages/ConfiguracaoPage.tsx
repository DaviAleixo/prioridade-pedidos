import Configuracao from '@/components/Configuracao';

const ConfiguracaoPage = () => {
  return <Configuracao />;
};

export default ConfiguracaoPage;
